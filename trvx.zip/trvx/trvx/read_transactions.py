# Python program to read gzip compressed JSON files and 
# send each transaction as a message to a Pub/Sun topic
# Considerations: 
# 1- I did not follow any best practices or design patterns 
# 2- As only for the test case, I didn't implement the auth process on the code, 
# use direct access via google cloud shell
# 3- Most of the parameters are harded coded, but for sure all 
# should be passed as parameters at the running process or using yaml files

import os
import json
import gzip
from pathlib import Path
from google.cloud import pubsub_v1

publisher = pubsub_v1.PublisherClient()
topic_name = 'projects/travix-home-test/topics/transactions'.format(
    project_id=os.getenv('GOOGLE_CLOUD_PROJECT'),
    topic='transactions',
)

# At this point I think to consider to implement a verification step of the name of the 
# topic to create it, if not exist on Pub/Sub service
#publisher.create_topic(name=topic_name)

# Step to check the location of the files
data_folder = Path("C:\\Users\\jeffe\\Desktop\\trvx\\datasets")
file_to_open = data_folder / "transactions.json.gz"

# Decompress GZIP and opening JSON file
with gzip.open(file_to_open,'r') as f:
	json_bytes = f.read()

# returns JSON object as a string
json_str = json_bytes.decode('utf-8')

# Converting the JSON string to a python dictionary 
data = json.loads(json_str)

# Iterating through the python dict and send the message to the Pub/Sub topic
for i in data['transactions']:
    message = json.dumps(i).encode('utf-8')
    future = publisher.publish(topic_name, data=message, spam='eggs')
    future.result()
    print(i)

# Closing file
f.close()